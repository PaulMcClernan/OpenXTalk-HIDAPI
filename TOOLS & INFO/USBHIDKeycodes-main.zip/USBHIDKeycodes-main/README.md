# USB HID Keycodes
Enum contains scan codes for HID. Can use this in any project. 
If its a C# project, add file as a link and set the build action to 'C# Compiler'.

*Public domain license is used, do whatever you want with this, just don't call me.*
