//
//  RootViewController.h
//  MacOSHid
//
//  Created by Smile on 2019/3/18.
//  Copyright © 2019年 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RootViewController : NSViewController

@property (nonatomic, strong)NSWindow *mainWindow;           //主窗口

@end
