//
//  main.m
//  MacOSHid
//
//  Created by Smile on 2019/3/18.
//  Copyright © 2019年 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
