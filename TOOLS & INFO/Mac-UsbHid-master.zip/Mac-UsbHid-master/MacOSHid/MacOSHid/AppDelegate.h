//
//  AppDelegate.h
//  MacOSHid
//
//  Created by Smile on 2019/3/18.
//  Copyright © 2019年 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

