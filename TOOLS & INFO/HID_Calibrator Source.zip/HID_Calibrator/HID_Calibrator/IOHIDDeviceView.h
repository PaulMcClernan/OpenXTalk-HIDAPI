//
//  IOHIDDeviceView.h
//  HID_Calibrator
//
//  Created by George Warner on 6/17/13.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface IOHIDDeviceView : NSView

@end
